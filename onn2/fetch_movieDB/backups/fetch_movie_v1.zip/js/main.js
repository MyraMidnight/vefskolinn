fetch ("https://api.themoviedb.org/3/discover/movie?api_key=92faef4c2a01d2027019eaa0cbcd34a7&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=1")
	.then ((results)=>{ //promise
		return results.json();
	})
	.then((json)=>{  //þegar api er búið að hlaða
		json.results.map((item)=>{
			item.poster_path = "https://image.tmdb.org/t/p/w300_and_h450_bestv2" + item.poster_path; //add to the url to display image
			return item;
			
		}).forEach((item)=>{
			const movieItem = {...item}; //fill each object with the movie info
			movieList.push(movieItem); //push each object into movieList array
		});	
		
	});
	
const movieList = []; //empty movie array to be filled with movieItem objects
const pageLength = 10; //how many items per page

const createPage = (movieArr)=>{
	//make script generate one page
	//remove each item from the movieList array to prevent duplicates
	let movieItemCounter = 0;	//counts how many items have been created on page
	
	const movieItem = (movieItem)=>{ //html for each movie list item
		while (movieItemCounter <= pageLength){ //while index is less than pageLength
			document.getElementById("movieList").innerHTML += `
				<div class="movieItem">
					<img src="${movieItem[i].poster_path}">
					<ul>
						<li><h2>${movieItem[i].original_title}</h2></li>
						<li>Rating: <em>${movieItem[i].vote_average}</em></li>
						<li>Release date: <em>${movieItem.release_date.slice(0,-6)}</em></li>
						<li class="desc">${movieItem.overview}</li>
					</ul>
				</div>
			`;
			movieItemCounter++; //add to the counter
		};
		movieArr.splice(0,movieItemCounter); //remove number of items from movieList 
	};
	movieItemCounter = 0; //resets the counter for next page
};

createPage(movieList);
//detect when user scrolls to bottom
const loadMorePages = ()=>{ //script that shall load more pages when user scrolls to bottom
	
	createPage(movieList);
};

console.log(movieList); //test movieList
