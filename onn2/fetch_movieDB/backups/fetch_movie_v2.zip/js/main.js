fetch ("https://api.themoviedb.org/3/discover/movie?api_key=92faef4c2a01d2027019eaa0cbcd34a7&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=1")
	.then ((results)=>{ //promise
		return results.json();
	})
	.then((json)=>{  //þegar api er búið að hlaða
		json.results.map((item)=>{
			item.poster_path = "https://image.tmdb.org/t/p/w300_and_h450_bestv2" + item.poster_path; //add to the url to display image
			return item;
			
		}).forEach((item)=>{
			const movieItem = {...item}; //fill each object with the movie info
			movieList.push(movieItem); //push each object into movieList array
		});	

		createPage(movieList); //create the first page

		//detect when user scrolls to bottom, then load more pages if items still exist on movieList array
		
	});
const movieList = []; //empty movie array to be filled with movie objects
const pageLength = 5; //how many items load per page

const createPage = (movieArr)=>{
	//might need to create a "if statement" for when movie items are less than pageLength
	
	let movieItemCounter = 0;	//counts how many items have been created on page
	while (movieItemCounter <= pageLength-1){ //run until page has been filled
		document.getElementById("movieList").innerHTML += `
			<div class="movieItem">
				<img src="${movieArr[movieItemCounter].poster_path}">
				<ul>
					<li><h2>${movieArr[movieItemCounter].original_title}</h2></li>
					<li>Rating: <em>${movieArr[movieItemCounter].vote_average}</em></li>
					<li>Release date: <em>${movieArr[movieItemCounter].release_date.slice(0,-6)}</em></li>
					<li class="desc">${movieArr[movieItemCounter].overview}</li>
				</ul>
			</div>
		`;
		movieItemCounter++; //add to the counter for each item
	};

	movieArr.splice(0,movieItemCounter); 
	//removes the number of items from movieList to prevent duplicates 
	movieItemCounter = 0; //resets the counter for next page
	
		console.log("movies left after page: ")//log how many items are left in movieList
		console.log(movieList); 
};
