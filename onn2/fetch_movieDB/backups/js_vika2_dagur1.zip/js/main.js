const apiUrl = "https://api.themoviedb.org/3/discover/movie?api_key=92faef4c2a01d2027019eaa0cbcd34a7&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=";
let currentPage = 1; //þessi tala hækkar í hvert sinn sem kallað er á "loadPage"

/* function sem hleður inn efni/pages með hjálp API */
const loadPage = ()=>{
	const request = apiUrl + currentPage; //púslar saman URL næstu síðu í hvert sinn
	
	fetch (request) // "request" variable sem er hér fyrir ofan
	.then ((results)=>{ //loforð um að hlaða API
		return results.json();
	})
	.then((json)=>{  //þegar API er loksins búið að hlaða
		json.results.map((item)=>{
			//til að myndahlekkur virki, þá nota ég map til að bæta eftirfarandi URL við poster_path
			item.poster_path = "https://image.tmdb.org/t/p/w300_and_h450_bestv2" + item.poster_path; 
			return item;
		}).forEach((item)=>{
			movieItem(item); //býr til movie hvert item með "movieItem"
		});	
		currentPage++;	// bætir við "currentPage" svo það hleður næstu síðu þegar "loadPage" er kallað næst
	});
};

/* function sem býr til HTML fyrir hvert item */
const movieItem = (item)=>{ 
	document.getElementById("movieList").innerHTML += `
		<div class="movieItem">
			<img src="${item.poster_path}">
			<ul>
				<li><h2>${item.original_title}</h2></li>
				<li>Rating: <em>${item.vote_average}</em></li>
				<li>Release date: <em>${item.release_date.slice(0,-6)}</em></li>
				<li class="desc">${item.overview}</li>
			</ul>
		</div>
	`
};

/* function sem fygljist með hvort viðkomandi sé kominn neðst á síðuna */
window.addEventListener("scroll", ()=>{ 
	const divWrap = document.getElementById("movieList");

	const windowHeight = window.innerHeight; //how tall is the window
	const pageHeight = divWrap.clientHeight - windowHeight; //how tall is page

	if ( window.scrollY >= pageHeight){ // ef viðkomandi er kominn alveg neðst á síðuna
		loadPage(); // þá skal ná í meira efni/pages
	};
});

loadPage(); 
