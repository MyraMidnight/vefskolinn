const apiUrl = "https://api.themoviedb.org/3/discover/movie?api_key=92faef4c2a01d2027019eaa0cbcd34a7&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=";
let currentPage = 1; //þessi tala hækkar í hvert sinn sem kallað er á "loadPage"
const allData = [];

/* function sem hleður inn efni/pages með hjálp API */
const loadPage = (filter)=>{
	const request = apiUrl + currentPage; //púslar saman URL næstu síðu í hvert sinn

	if (filter == "release_date" || filter == "vote_average" ){
			allData.sort((movieA, movieB)=>{
				if (filter == "release_date"){	
					return movieA.release_date - movieB.release_date;
				} else if ("vote_average") {
					return movieB.vote_average - movieA.vote_average;
				}
			}).forEach((movie)=>{
				movieItem(movie); //býr til movie hvert movie með "movieItem"
			});	
			currentPage++;	// bætir við "currentPage" svo það hleður næstu síðu þegar "loadPage" er kallað næst

	} else {
		fetch (request) // "request" variable sem er hér fyrir ofan
		.then ((results)=>{ //loforð um að hlaða API
			return results.json();
		})
		.then((json)=>{  //þegar API er loksins búið að hlaða
			json.results.map((movie)=>{
				//til að myndahlekkur virki, þá nota ég map til að bæta eftirfarandi URL við poster_path
				movie.poster_path = "https://image.tmdb.org/t/p/w300_and_h450_bestv2" + movie.poster_path; 
				movie.backdrop_path = "https://image.tmdb.org/t/p/w300_and_h450_bestv2" + movie.backdrop_path; 
				movie.release_date = movie.release_date;
				return movie;
			}).forEach((movie)=>{
				movieItem(movie); //býr til movie hvert movie með "movieItem"
				allData.push(movie);
			});	
			currentPage++;	// bætir við "currentPage" svo það hleður næstu síðu þegar "loadPage" er kallað næst
		});		
	};
};

loadPage(); //hleður inn fyrstu síðu af movies

/* function sem býr til HTML fyrir hvert movie */
const movieItem = (movie)=>{ 
	document.getElementById("movieList").innerHTML += `
		<div class="movieItem">
			<img src="${movie.poster_path}" id="movie_${movie.id}" onclick="moreInfo(${movie.id})">
			<ul>
				<li><h2>${movie.original_title}</h2></li>
				<li>Rating: <em>${movie.vote_average}</em></li>
				<li>Release date: <em>${movie.release_date}</em></li>
				<li class="desc">${movie.overview}</li>
			</ul>
		</div>
	`
};
//.slice(0,-6)
/* function sem fylgist með hvort viðkomandi sé kominn neðst á síðuna */
window.addEventListener("scroll", ()=>{ 
	const divWrap = document.getElementById("movieList");

	const windowHeight = window.innerHeight; //how tall is the window
	const pageHeight = divWrap.clientHeight - windowHeight; //how tall is page

	if ( window.scrollY >= pageHeight){ // ef viðkomandi er kominn alveg neðst á síðuna
		loadPage(); // þá skal ná í meira efni/pages
	};
});

/* function sem sortar listann eftir ári/rating 
Önnur leitin er með niðurstöður sem þú hefur hlaðið inn á síðuna með fetch um það bil 5 til 6 “pages” (en það eru um 100 myndir). Þar átt þú að nota search function-ið sem þú gerðir í síðustu viku.
*/

const filterMovies = (filter)=>{
	const moviesWrap = document.getElementById("movieList");
	
	
	moviesWrap.innerHTML = "";
	loadPage(filter); 
	
};

/* function sem leyfir viðkomandi að leita í gegnum TheMovieDB 
Hin leitin notar search  úr TMDB apanum (https://developers.themoviedb.org/3/search/search-movies)
*/

const searchMovies = ()=>{
	const moviesWrap = document.getElementById("movieList");	
	
	moviesWrap.innerHTML = "";

};

/* function sem býr til popup með nánari upplýsingum um valda mynd 
Þegar smellt er á bíómynd á síðunni kemur upp modal (líka á leitarsíðum) með meiri upplýsingum um myndina þar þurfa að vera a.m.k. 3 mismunandi köll í apann (t.d. Get Credits, Get Videos og Get Details)
*/

const moreInfo = (movieId) => {
	console.log("clicked");
	console.log(movieId);
	
	const popup = document.getElementById("popup"); 
	const movieImage = document.getElementById("movie_"+movieId);

	//ná í upplýsingar frá element sem smellt var á til að fá réttar upplýsingar fyrir popup
	//vísa í item úr results array (einhvernveginn)
	
	clickedElement.onclick = ()=>{
		popup.style.display = "flex"; //birtir popup (sem er hidden venjulega)
		popup.style.backgroundImage = this.backdrop_path; //setja bakgrunn á popup 
		popup.innerHTML = `
			<h3>Fleirri upplýsingar</h3>
		`;
		
		//setja "display:hidden" þegar smellt er útfyrir popup, til að loka honum
	};
};


